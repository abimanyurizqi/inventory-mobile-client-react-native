import React, { Component } from 'react';
import { View, AsyncStorage } from 'react-native';
import { Container, Header, Title, Content, Footer, FooterTab, Button, Left, Right, Body, Icon, Text } from 'native-base';
import { CommonHeader } from '../../components/CommonHeader';




class HomeScreen extends Component {

    constructor(props){
        super(props);
        this.state={
            username: ''
        };
    }

    componentDidMount(){
        this.mountUsername()

    }

    mountUsername = async () => {
       const username = await AsyncStorage.getItem('username')
       this.setState({
            username: username
       })
    }

    render() {
        const{navigation} = this.props
        const{username}=this.state
        return (
            <Container>
                <Content>
                    <CommonHeader navigation={navigation} title="Home" hideRightButton={true}/>
                    <View>
                        <Text> Hello {username}!! </Text>
                    </View>
                </Content>
            </Container>
        );
    }
}


export default HomeScreen