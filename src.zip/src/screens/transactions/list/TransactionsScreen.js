import React, { Component } from 'react';
import { View, RefreshControl, TouchableOpacity, FlatList, Alert } from 'react-native';
import { Container, Header, Title, Content, Fab, Footer, FooterTab, Input, Item, Button, Left, Right, Body, Text, ListItem, List, Toast } from 'native-base';
import { CommonHeader } from '../../../components/CommonHeader';
import PropTypes from 'prop-types';
import styles from './styles';
import { connect } from 'react-redux';
import { findAll, deleteById } from '../../../actions/transactions';
import { SwipeListView } from 'react-native-swipe-list-view';
import {showError, showSuccess} from '../../../utils/toast';
import Icon from 'react-native-vector-icons/FontAwesome';



function Transactions({ transaction, onPress }) {
    return (
        <ListItem style={styles.item}>
            <Left>
                <Text>
                    {transaction.typeTransaction}
                </Text>
            </Left>
            <Body>
                <Text>Rp.{transaction.amount}</Text>
                <Text note numberOfLines={1}>{transaction.description}</Text>
            </Body>
            <Right>
                <Button transparent onPress={() => onPress(transaction)}>
                    <Text style={{color: '#788ad2'}}>Edit</Text>
                </Button>
            </Right>
        </ListItem>
    )
}

class TransactionsScreen extends Component {

    constructor(props) {
        super(props)
        this.state = {
            data: [],
            total: 0,
            params: {
                search: '',
                sort: 'asc',
                page: 0

            }
        }


    }

    componentDidMount() {
        this.reload(this.state.params);
        
    }

    componentDidUpdate(prevProps, prevState) {
        const { data, error, addData, editData, deleteData, deleteError } = this.props;
        if (prevProps.data !== data) {
            this.setState({
                data: [...this.state.data, ...data.list],
                total: data.total,
                search: this.state.params.search,
                params: {
                    ...this.state.params,
                    page: data.page
                }
            });
            console.log(this.props.data.list)
        } else if (prevProps.addData !== addData) {
            this.onRefresh();
            showSuccess('data has been added');
        } else if (prevProps.editData !== editData) {
            this.onRefresh();
            showSuccess('data has been edited');
        } else if (prevProps.deleteData !== deleteData) {
            this.onRefresh();
        } else if (error && prevProps.error !== error) {
            showError(error);
        } else if (deleteError && prevProps.deleteError !== deleteError) {
            showError(error);
        }
    }

    reload({ search, sort = 'asc', page = 0 } = {}) {
        this.props.findAll({ search, sort, page });
    }

    onRefresh = () => {
        const { params } = this.state;
        this.setState({
            data: [],
            total: 0,
            params: { ...params, page: 0 }
        }, () => this.reload(this.state.params)
        );

    }

    onAdd = () => {
        this.props.navigation.navigate('Transaction');
    }

    onShowForm = (item) => {
        this.props.navigation.navigate('Transaction', item ? { id: item.id } : null);
    }

    onEndReached = () => {
        const { data, total, params } = this.state;
        if (data.length < total) {
            this.reload({
                ...params,
                page: params.page + 1
            });
        }


    }

    onDelete = (data) => {
        Alert.alert(
            "Confirmation",
            "Are you sure want to delete this item?",
            [
                { text: "Cancel", style: "cancel" },
                { text: "Yes", onPress: () => this.props.deleteById(data.id) }
            ]
        );

    }


    render() {
        const { navigation, loading } = this.props;
        const { data, search } = this.state;
        return (
            <Container>
                <CommonHeader navigation={navigation} title="Transactions" add={this.onAdd} />
                <View style={styles.content}>

                    <SwipeListView refreshControl={
                        <RefreshControl refreshing={loading} onRefresh={this.onRefresh} />
                    }
                        data={data}
                        renderItem={({ item }) => <Transactions transaction={item} onPress={this.onShowForm} />}
                        keyExtractor={item => item.id.toString()}
                        onEndReached={this.onEndReached}
                        onEndReachedThreshold={0.5}
                        renderHiddenItem={(data) => (
                            <TouchableOpacity
                                style={styles.deleteButton}
                                onPress={() => this.onDelete(data.item)}
                            >
                                <Icon color='#fff' name="trash-o" size={20} />
                            </TouchableOpacity>
                        )}
                        rightOpenValue={-75}
                        disableRightSwipe


                    />
                </View>
            </Container>
        );
    }
}



const mapStateToProps = state => ({
    data: state.transactions.data,
    loading: state.transactions.loading || state.deletedTransactionById.loading,
    error: state.transactions.error,

    addData: state.addedTransaction.data,
    editData: state.editedTransaction.data,

    deleteData: state.deletedTransactionById.data,
    deleteError: state.deletedTransactionById.Error
});

const mapDispatchToProps = {
    findAll,
    deleteById
};



export default connect(mapStateToProps, mapDispatchToProps)(TransactionsScreen)
