import React, { Component } from 'react';
import { Container, Content, Text, Button, Body, Left, Right, ListItem } from 'native-base';
import { ImageBackground } from 'react-native';
import styles from './styles';
import Icon from 'react-native-vector-icons/FontAwesome';


const items = [{
    icon: 'home',
    label: 'Home',
    target: 'Home'
},
{
    icon: 'tags',
    label: 'Items',
    target: 'Items'
},
{
    icon: 'th',
    label: 'Units',
    target: 'Units'
},
{
    icon: 'dropbox',
    label: 'Stocks',
    target: 'Stocks'
},
{
    icon: 'money',
    label: 'Transactions',
    target: 'Transactions'
},
]

function DrawerItem({ navigation, item }) {
    return (
        <ListItem icon onPress={() => navigation.navigate(item.target)}>
            <Left>
                <Icon name={item.icon} />
            </Left>
            <Body>
                <Text>
                    {item.label}
                </Text>
            </Body>
        </ListItem>
    );
}

class CommonDrawer extends Component {
    render() {
        const { navigation } = this.props;
        return (
            <Container>
                <ImageBackground source={require('../../../assets/images/drawer.jpg')} style={styles.image} >
                    <Text>inside</Text>
                </ImageBackground>
                <Content>

                    {items.map((item, index) =>
                        <DrawerItem
                            key={index}
                            navigation={navigation}
                            item={item} />
                    )}

                </Content>
            </Container>
        )
    }
}

export default CommonDrawer;