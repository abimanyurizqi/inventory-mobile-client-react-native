import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
    image: {
        height: 140,
        resizeMode: "cover",
        justifyContent: "center"
    }
});

export default styles
